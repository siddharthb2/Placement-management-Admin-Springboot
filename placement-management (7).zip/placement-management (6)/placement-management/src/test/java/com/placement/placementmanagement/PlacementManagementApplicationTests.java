package com.placement.placementmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.placement.placementmanagement.model.Admin;
import com.placement.placementmanagement.model.Employee;
import com.placement.placementmanagement.repository.AdminRespository;
import com.placement.placementmanagement.repository.EmployeeRepository;

@SpringBootTest
class PlacementManagementApplicationTests {

	@Test
	void contextLoads() {
	}
	
	@Autowired
	AdminRespository adminRespository;
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	@Test
	public void testCreateAdmin() {
	    Admin admin = new Admin();
	    admin.setPassword("admin2");
	    admin.setUserName("admin123");
	    Admin savedAdmin = adminRespository.save(admin);    
	}
	
	@Test
	public void testCreateEmployee() {
		Employee employee = new Employee();
		employee.setEmpid("46750");
		employee.setEmail("vidhu@gmail.com");
		employee.setCity("Chennai");
		employee.setCountry("India");
		employee.setDesignation("Tester");
		employee.setFirstName("Vidya");
		employee.setLastName("S");
		employee.setNumber("98658955");
		Employee savedEmployee = employeeRepository.save(employee);		 
	}

}
