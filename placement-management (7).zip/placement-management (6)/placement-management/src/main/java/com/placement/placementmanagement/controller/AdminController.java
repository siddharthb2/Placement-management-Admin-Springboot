package com.placement.placementmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.placement.placementmanagement.exception.InvalidInputException;
import com.placement.placementmanagement.model.Admin;
import com.placement.placementmanagement.service.AdminService;

@RestController
public class AdminController {
	
	@Autowired
	AdminService adminService;
	
	//add new admin
	@PostMapping("/admin/add")
	public Admin saveAdmin(@RequestBody Admin admin) {
		return adminService.saveAdmin(admin);
	}
	
	//get the list of admin
	@GetMapping("/admin/lists")
	public List<Admin> getAllAdmins(){
		return adminService.getAllAdmin();
	}
	
	//get the admin detail using id,if id value <= 0 exception will be thrown
	@GetMapping("/admin/{id}")
	public ResponseEntity<Admin> getAdminById(@PathVariable int id){
		if(id <= 0) {
			throw new InvalidInputException(id+" is not a valid Admin ID");
		}
		Admin admin = adminService.getAdminByid(id);
		return new ResponseEntity<Admin>(admin,HttpStatus.OK);

	}
	
	//Using Delete method deleting admin using id, and if id not is <= 0 exception will be thrown
	@DeleteMapping("/admin/{id}")
	public String deleteAdmin(@PathVariable int id) {
		if(id <= 0) {
			throw new InvalidInputException(id+" is not a valid Admin ID");
		}
		adminService.deleteAdmin(id);
		return "Deleted Successfully";
	}
	
	//Using Put method updating admin detail using id
	@PutMapping("/admin/{id}")
	public ResponseEntity<Admin> updateAdmin(@PathVariable(value = "id") int id,
			@RequestBody Admin admin){
		if(id <= 0) {
			throw new InvalidInputException(id+" is not a valid Admin ID");
		}
		Admin updatedAdmin =adminService.upadateAdmin(id, admin);
		return ResponseEntity.ok(updatedAdmin);
	}
	
}
