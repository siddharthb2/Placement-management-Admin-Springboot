package com.placement.placementmanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.placement.placementmanagement.model.Company;
import com.placement.placementmanagement.repository.CompanyRepository;
import com.placement.placementmanagement.service.CompanyService;

@Service
public class CompanyServiceImpl implements CompanyService{

	@Autowired
	CompanyRepository companyRepo;
	@Override
	public List<Company> getAllCompany() {
		return companyRepo.findAll();
	}

}
