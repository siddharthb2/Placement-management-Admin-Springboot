package com.placement.placementmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


import com.placement.placementmanagement.model.Placement;
import com.placement.placementmanagement.service.PlacementService;


@Controller
public class PlacementViewController {

	@Autowired
	PlacementService placementService;
	
	
	//To display Placement list
	@RequestMapping("/placementlist")
	public String viewPlacementListPage(Model model) {
		List<Placement> placementList = placementService.getAllPlacement();
		model.addAttribute("placementList", placementList);
		return "placementlist";
	}
	}
