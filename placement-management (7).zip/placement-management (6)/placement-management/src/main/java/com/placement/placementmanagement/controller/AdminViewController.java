package com.placement.placementmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.placement.placementmanagement.model.Admin;
import com.placement.placementmanagement.service.AdminService;

@Controller
public class AdminViewController {
	
	@Autowired
	AdminService adminService;
	
	//To display admin list
	@RequestMapping("/adminlist")
	public String viewIndexPage(Model model) {
		List<Admin> adminList = adminService.getAllAdmin();
		model.addAttribute("adminList",adminList);
		return "admin_list";
	}
	
	//To add new Admin
	@RequestMapping("/admin/add")
	public String viewNewAdminPage(Model model) {
		Admin admin = new Admin();
		model.addAttribute("admin", admin);
		return "new_admin";
	}
	
	//To save admin details in database
	@RequestMapping(value = "/saveadmin", method = RequestMethod.POST)
	public String saveAdmin(@ModelAttribute("admin") Admin admin) {
		adminService.saveAdmin(admin);
		return "redirect:/";
	}
	
	//edit the admin detail using id
	@RequestMapping("/admin/edit/{id}")
	public ModelAndView showEditAminPage(@PathVariable(name="id") int id) {
		ModelAndView mav = new ModelAndView("edit_admin");
		Admin admin = adminService.getAdminByid(id);
		mav.addObject("admin", admin);
		return mav;
	}
	
	//delete admin details from admin list
	@RequestMapping("/delete/{id}")
	public String deleteAdmin(@PathVariable(name="id") int id) {
		adminService.deleteAdmin(id);
		return "redirect:/";
	}
	
}

