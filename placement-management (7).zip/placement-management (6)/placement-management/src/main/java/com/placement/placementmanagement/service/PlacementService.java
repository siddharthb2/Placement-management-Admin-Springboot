package com.placement.placementmanagement.service;

import java.util.List;

import com.placement.placementmanagement.model.Placement;


public interface PlacementService {
	
	public List<Placement> getAllPlacement();
	
}
