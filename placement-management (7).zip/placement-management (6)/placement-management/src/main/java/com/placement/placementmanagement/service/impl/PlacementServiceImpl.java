package com.placement.placementmanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.placement.placementmanagement.model.Placement;
import com.placement.placementmanagement.repository.PlacementRepository;
import com.placement.placementmanagement.service.PlacementService;

@Service
public class PlacementServiceImpl implements PlacementService {

	@Autowired
	PlacementRepository placementRepo;

	@Override
	public List<Placement> getAllPlacement() {
		return placementRepo.findAll();
	}
	
}
