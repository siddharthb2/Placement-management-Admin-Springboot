package com.placement.placementmanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.placement.placementmanagement.exception.RecordNotFoundException;
import com.placement.placementmanagement.model.Admin;
import com.placement.placementmanagement.repository.AdminRespository;
import com.placement.placementmanagement.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	AdminRespository adminRepo;
	
	@Override
	public Admin saveAdmin(Admin admin) {
		return adminRepo.save(admin);
	}

	@Override
	public List<Admin> getAllAdmin() {
		return adminRepo.findAll();
	}

	@Override
	public Admin getAdminByid(int id) {
		return adminRepo.findById(id).orElseThrow(()-> new RecordNotFoundException("Id not found"));
	}

	@Override
	public Admin upadateAdmin(int id, Admin admin) {
		Admin a1 = getAdminByid(id);
		a1.setPassword(admin.getPassword());
		return adminRepo.save(a1);
	}

	@Override
	public void deleteAdmin(int id) {
		Admin admin = getAdminByid(id);
		adminRepo.delete(admin);
	}

}
