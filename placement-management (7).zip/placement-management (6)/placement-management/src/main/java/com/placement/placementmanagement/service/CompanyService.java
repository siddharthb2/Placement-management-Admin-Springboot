package com.placement.placementmanagement.service;

import java.util.List;

import com.placement.placementmanagement.model.Company;

public interface CompanyService {
	
	public List<Company> getAllCompany();
}
