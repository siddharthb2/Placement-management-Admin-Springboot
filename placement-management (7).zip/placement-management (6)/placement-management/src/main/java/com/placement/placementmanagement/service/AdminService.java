package com.placement.placementmanagement.service;

import java.util.List;

import com.placement.placementmanagement.model.Admin;

public interface AdminService {

	public Admin saveAdmin(Admin admin);
	
	public List<Admin> getAllAdmin();
	
	public Admin getAdminByid(int id);
	
	public Admin upadateAdmin(int id,Admin admin);
	
	public void deleteAdmin(int id);
	
}
