package com.placement.placementmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.placement.placementmanagement.model.Company;
import com.placement.placementmanagement.service.CompanyService;

@Controller
public class CompanyViewController {
	
	@Autowired
	CompanyService companyService;
	
	//To display company list
	@RequestMapping("/companylist")
	public String viewIndexPage(Model model) {
		List<Company> companyList = companyService.getAllCompany();
		model.addAttribute("companyList",companyList);
		return "company_list";
	}
}
