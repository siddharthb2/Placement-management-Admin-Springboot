package com.placement.placementmanagement.service.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.placement.placementmanagement.model.Admin;
import com.placement.placementmanagement.repository.LoginRepository;

@Service
public class LoginServiceImpl {

	@Autowired
	private LoginRepository repo;
	  
	public Admin login(String userName, String password) {
		Admin admin = repo.findByUserNameAndPassword(userName, password);
		return admin;
	  }
}