package com.placement.placementmanagement.service;

import java.util.List;

import com.placement.placementmanagement.model.User;

public interface UserService {

	public User saveUser(User user);
	
	public List<User> getAllUser();
	
}
